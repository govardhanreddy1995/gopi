/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#2C3E50',
          light: '#34495E',
          dark: '#1A2530',
          darker: '#0E1621',
        },
        secondary: {
          DEFAULT: '#7D6E83',
          light: '#9A8BA0',
          dark: '#5F5366',
          darker: '#433A49',
        },
        accent: {
          DEFAULT: '#E67E22',
          light: '#F39C12',
          dark: '#D35400',
          darker: '#A04000',
        },
        success: {
          DEFAULT: '#2ECC71',
          light: '#27AE60',
          dark: '#229954',
          darker: '#1E8449',
        },
        warning: {
          DEFAULT: '#F1C40F',
          light: '#F39C12',
          dark: '#CA6F1E',
          darker: '#A04000',
        },
        error: {
          DEFAULT: '#E74C3C',
          light: '#F03022',
          dark: '#C0392B',
          darker: '#922B21',
        },
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
      animation: {
        fadeIn: 'fadeIn 0.8s ease-in-out',
        slideUp: 'slideUp 0.8s ease-in-out',
        slideDown: 'slideDown 0.8s ease-in-out',
        slideLeft: 'slideLeft 0.8s ease-in-out',
        slideRight: 'slideRight 0.8s ease-in-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        slideDown: {
          '0%': { transform: 'translateY(-20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        slideLeft: {
          '0%': { transform: 'translateX(20px)', opacity: '0' },
          '100%': { transform: 'translateX(0)', opacity: '1' },
        },
        slideRight: {
          '0%': { transform: 'translateX(-20px)', opacity: '0' },
          '100%': { transform: 'translateX(0)', opacity: '1' },
        },
      },
    },
  },
  plugins: [],
};