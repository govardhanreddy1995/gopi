import React from 'react';
import { projects } from '../../data/projects';
import Button from '../ui/Button';
import { ExternalLink } from 'lucide-react';

const ProjectShowcase: React.FC = () => {
  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="inline-block text-primary text-sm font-semibold tracking-wider uppercase mb-2">Inspiration</span>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Featured Projects</h2>
          <p className="mt-4 max-w-2xl mx-auto text-gray-600">
            Take a look at some impressive construction projects completed using our premium materials.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <div key={project.id} className="group overflow-hidden rounded-lg shadow-md bg-white transition-all hover:shadow-lg">
              <div className="relative aspect-video overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent opacity-50 group-hover:opacity-70 transition-opacity"></div>
                <div className="absolute bottom-0 left-0 p-4">
                  <span className="inline-block bg-primary py-1 px-2 rounded text-xs text-white font-medium">
                    {project.type}
                  </span>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-800 mb-2 group-hover:text-primary transition-colors">
                  {project.title}
                </h3>
                <p className="text-gray-600 mb-4">
                  {project.description}
                </p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.materials.map((material, index) => (
                    <span 
                      key={index} 
                      className="text-xs bg-gray-100 text-gray-700 py-1 px-2 rounded"
                    >
                      {material}
                    </span>
                  ))}
                </div>
                
                <div className="flex items-center justify-between mt-4">
                  <span className="text-sm text-gray-500">{project.location}</span>
                  <Button 
                    variant="outline" 
                    size="sm"
                    icon={<ExternalLink size={14} />}
                  >
                    View Details
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-10">
          <Button variant="primary" size="lg">
            View All Projects
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ProjectShowcase;