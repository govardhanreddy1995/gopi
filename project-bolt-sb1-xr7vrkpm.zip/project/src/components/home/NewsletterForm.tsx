import React, { useState } from 'react';
import Button from '../ui/Button';

const NewsletterForm: React.FC = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      setError('Please enter an email address');
      return;
    }
    
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setError('Please enter a valid email address');
      return;
    }
    
    // Simulate API call
    setTimeout(() => {
      setSubmitted(true);
      setError('');
    }, 500);
  };

  return (
    <section className="py-16 bg-gray-100">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
          <div className="flex flex-col md:flex-row">
            <div className="md:w-2/5 bg-primary p-8 text-white flex items-center">
              <div>
                <h3 className="text-2xl font-bold mb-4">Stay Updated</h3>
                <p className="text-white/80 mb-4">
                  Subscribe to our newsletter to receive updates on new products, 
                  special offers, and expert building tips.
                </p>
                <ul className="space-y-2">
                  {['Exclusive deals', 'New product alerts', 'Expert tips', 'Project inspiration'].map((item, index) => (
                    <li key={index} className="flex items-center">
                      <svg className="w-5 h-5 mr-2 text-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            
            <div className="md:w-3/5 p-8 flex items-center">
              {submitted ? (
                <div className="text-center w-full">
                  <svg className="w-16 h-16 text-green-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                  </svg>
                  <h3 className="text-2xl font-bold text-gray-800 mb-2">Thank You for Subscribing!</h3>
                  <p className="text-gray-600">
                    You'll now receive our latest updates and special offers directly to your inbox.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="w-full">
                  <h3 className="text-2xl font-bold text-gray-800 mb-4">Subscribe to Our Newsletter</h3>
                  <div className="mb-4">
                    <label htmlFor="email" className="block text-gray-700 mb-2">Email Address</label>
                    <input
                      type="email"
                      id="email"
                      value={email}
                      onChange={(e) => {
                        setEmail(e.target.value);
                        setError('');
                      }}
                      className={`w-full px-4 py-2 border ${
                        error ? 'border-red-500' : 'border-gray-300'
                      } rounded-md focus:outline-none focus:ring-2 focus:ring-primary`}
                      placeholder="your@email.com"
                    />
                    {error && <p className="mt-1 text-red-500 text-sm">{error}</p>}
                  </div>
                  
                  <div className="flex flex-wrap items-center mb-4">
                    <label className="flex items-center">
                      <input type="checkbox" className="w-4 h-4 text-primary" />
                      <span className="ml-2 text-sm text-gray-600">
                        I agree to receive promotional emails
                      </span>
                    </label>
                  </div>
                  
                  <Button 
                    type="submit" 
                    variant="accent" 
                    fullWidth
                  >
                    Subscribe Now
                  </Button>
                  
                  <p className="mt-4 text-xs text-gray-500 text-center">
                    By subscribing, you agree to our Terms of Service and Privacy Policy.
                    You can unsubscribe at any time.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default NewsletterForm;