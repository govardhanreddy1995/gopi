import React from 'react';
import Button from '../ui/Button';
import { Link } from '../ui/Link';
import { ArrowRight } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative bg-gradient-to-r from-gray-900 to-gray-800 h-[75vh] min-h-[600px] flex items-center">
      {/* Overlay with semi-transparent construction pattern */}
      <div className="absolute inset-0 bg-repeat opacity-10 bg-[url('https://www.transparenttextures.com/patterns/brick-wall.png')]"></div>
      
      {/* Content container */}
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-2xl text-white">
          <span className="inline-block bg-accent py-1 px-3 rounded text-sm font-bold mb-4 animate-fadeIn">
            Premium Construction Materials
          </span>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight animate-slideUp">
            Building The Future, <span className="text-accent">Quality By Quality</span>
          </h1>
          
          <p className="text-lg md:text-xl text-gray-300 mb-8 animate-slideUp animation-delay-100">
            From foundation to finish, we provide premium construction materials 
            for contractors, builders, and DIY enthusiasts. Quality that stands the test of time.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 animate-slideUp animation-delay-200">
            <Button 
              size="lg" 
              variant="accent"
              icon={<ArrowRight size={18} />}
            >
              Shop Now
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="border-white text-white hover:bg-white hover:bg-opacity-10"
            >
              View Projects
            </Button>
          </div>
          
          <div className="flex items-center mt-12 animate-fadeIn animation-delay-300">
            <div className="flex -space-x-2">
              {[1, 2, 3, 4].map(id => (
                <img 
                  key={id}
                  src={`https://randomuser.me/api/portraits/men/${id + 30}.jpg`} 
                  alt="Customer" 
                  className="w-10 h-10 rounded-full border-2 border-white"
                />
              ))}
            </div>
            <div className="ml-4">
              <div className="flex items-center mb-1">
                {[...Array(5)].map((_, i) => (
                  <svg 
                    key={i} 
                    className="w-4 h-4 text-yellow-500"
                    fill="currentColor" 
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <p className="text-sm text-gray-300">
                <span className="font-semibold">4.9/5</span> from over <span className="font-semibold">2,000+</span> happy customers
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div className="hidden lg:block absolute right-0 bottom-0 w-2/5 h-4/5">
        <div className="relative w-full h-full">
          <div className="absolute bottom-0 right-0 w-full h-full bg-accent/20 backdrop-blur-sm rounded-tl-3xl overflow-hidden">
            <img 
              src="https://images.pexels.com/photos/2760241/pexels-photo-2760241.jpeg" 
              alt="Construction site" 
              className="w-full h-full object-cover mix-blend-overlay"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;