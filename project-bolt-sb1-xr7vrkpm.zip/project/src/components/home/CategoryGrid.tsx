import React from 'react';
import { categories } from '../../data/categories';
import { Link } from '../ui/Link';
import { ArrowRight } from 'lucide-react';

const CategoryGrid: React.FC = () => {
  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="inline-block text-primary text-sm font-semibold tracking-wider uppercase mb-2">Explore Our Categories</span>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Find Materials by Category</h2>
          <p className="mt-4 max-w-2xl mx-auto text-gray-600">
            Browse our extensive range of construction materials organized by category to find exactly what you need for your project.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category) => (
            <Link 
              key={category.id}
              href={`/products?category=${category.slug}`}
              className="group block"
            >
              <div className="relative overflow-hidden rounded-lg">
                <img 
                  src={category.image} 
                  alt={category.name} 
                  className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent opacity-80"></div>
                <div className="absolute bottom-0 left-0 p-6">
                  <h3 className="text-xl font-semibold text-white mb-1">{category.name}</h3>
                  <p className="text-sm text-gray-300 mb-3">{category.productCount} products</p>
                  <span className="inline-flex items-center text-sm font-medium text-white">
                    View Category <ArrowRight className="ml-1 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoryGrid;