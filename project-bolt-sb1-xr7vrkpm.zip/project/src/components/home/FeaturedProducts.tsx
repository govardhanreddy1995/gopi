import React from 'react';
import ProductCard from '../ui/ProductCard';
import { featuredProducts } from '../../data/products';

const FeaturedProducts: React.FC = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="inline-block text-primary text-sm font-semibold tracking-wider uppercase mb-2">Special Selection</span>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Featured Products</h2>
          <p className="mt-4 max-w-2xl mx-auto text-gray-600">
            Discover our handpicked selection of premium construction materials, tools, and supplies for your next project.
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;