export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  oldPrice: number;
  discount: number;
  category: string;
  image: string;
  inStock: boolean;
  rating: number;
  reviewCount: number;
  features: string[];
}