import { Product } from '../types/product';

export const products: Product[] = [
  {
    id: '1',
    name: 'Premium Portland Cement',
    description: 'High-quality portland cement for various construction applications. Provides excellent strength and durability for concrete structures.',
    price: 14.99,
    oldPrice: 19.99,
    discount: 25,
    category: 'Building Materials',
    image: 'https://images.pexels.com/photos/6448739/pexels-photo-6448739.jpeg',
    inStock: true,
    rating: 4.8,
    reviewCount: 124,
    features: [
      'High strength development',
      'Consistent quality',
      'Versatile application',
      '94 lb bag'
    ]
  },
  {
    id: '2',
    name: 'Heavy-Duty Steel I-Beam',
    description: 'Structural steel I-beam for heavy load-bearing applications. Ideal for commercial and industrial construction projects.',
    price: 89.50,
    oldPrice: 0,
    discount: 0,
    category: 'Structural Components',
    image: 'https://images.pexels.com/photos/2760241/pexels-photo-2760241.jpeg',
    inStock: true,
    rating: 4.9,
    reviewCount: 56,
    features: [
      'High load capacity',
      'Precise dimensions',
      'ASTM A36 certified steel',
      'Various lengths available'
    ]
  },
  {
    id: '3',
    name: 'Professional Cordless Drill Set',
    description: 'Powerful 20V cordless drill with lithium-ion battery, charger, and carrying case. Perfect for construction professionals and DIY enthusiasts.',
    price: 129.99,
    oldPrice: 159.99,
    discount: 18,
    category: 'Tools & Equipment',
    image: 'https://images.pexels.com/photos/1249611/pexels-photo-1249611.jpeg',
    inStock: true,
    rating: 4.7,
    reviewCount: 342,
    features: [
      '20V lithium-ion battery',
      'LED work light',
      'Variable speed control',
      'Includes bits and accessories'
    ]
  },
  {
    id: '4',
    name: 'Pressure-Treated Lumber 2×4',
    description: 'High-quality pressure-treated lumber resistant to rot, decay, and termites. Ideal for outdoor construction projects.',
    price: 8.75,
    oldPrice: 0,
    discount: 0,
    category: 'Building Materials',
    image: 'https://images.pexels.com/photos/5691622/pexels-photo-5691622.jpeg',
    inStock: true,
    rating: 4.5,
    reviewCount: 78,
    features: [
      'Rot and decay resistant',
      'Termite protection',
      '8 ft length',
      'Sustainable sourcing'
    ]
  },
  {
    id: '5',
    name: 'Premium Ceramic Floor Tiles',
    description: 'Elegant ceramic floor tiles with a modern finish. Durable, easy to clean, and perfect for kitchens, bathrooms, and living spaces.',
    price: 3.49,
    oldPrice: 4.99,
    discount: 30,
    category: 'Flooring',
    image: 'https://images.pexels.com/photos/6074935/pexels-photo-6074935.jpeg',
    inStock: true,
    rating: 4.6,
    reviewCount: 215,
    features: [
      'Stain resistant',
      'Easy maintenance',
      '12" x 12" size',
      'Frost resistant'
    ]
  },
  {
    id: '6',
    name: 'Heavy-Duty Safety Helmet',
    description: 'ANSI-certified construction safety helmet with adjustable suspension for maximum comfort and protection on the job site.',
    price: 24.95,
    oldPrice: 29.95,
    discount: 16,
    category: 'Safety Equipment',
    image: 'https://images.pexels.com/photos/159358/construction-site-build-construction-work-159358.jpeg',
    inStock: true,
    rating: 4.9,
    reviewCount: 167,
    features: [
      'ANSI Z89.1 certified',
      'Adjustable suspension',
      'UV protection',
      'Ventilated design for comfort'
    ]
  },
  {
    id: '7',
    name: 'Interior Latex Wall Paint',
    description: 'Premium low-VOC interior latex paint that provides excellent coverage and a smooth, long-lasting finish.',
    price: 32.99,
    oldPrice: 0,
    discount: 0,
    category: 'Paints & Finishes',
    image: 'https://images.pexels.com/photos/6444247/pexels-photo-6444247.jpeg',
    inStock: true,
    rating: 4.7,
    reviewCount: 298,
    features: [
      'Low VOC formula',
      'Excellent coverage',
      'Mildew resistant',
      '1 gallon size'
    ]
  },
  {
    id: '8',
    name: 'Professional Circular Saw',
    description: 'Heavy-duty 15-amp circular saw with laser guide for precise cutting. Essential for framing, decking, and general construction work.',
    price: 119.00,
    oldPrice: 149.00,
    discount: 20,
    category: 'Tools & Equipment',
    image: 'https://images.pexels.com/photos/2138126/pexels-photo-2138126.jpeg',
    inStock: true,
    rating: 4.8,
    reviewCount: 184,
    features: [
      '15-amp motor',
      'Laser guidance system',
      'Bevel capacity 0-56°',
      'Electric brake for safety'
    ]
  }
];

export const featuredProducts = products.filter(product => 
  ['1', '3', '5', '8'].includes(product.id)
);