interface Project {
  id: string;
  title: string;
  description: string;
  type: string;
  image: string;
  location: string;
  materials: string[];
}

export const projects: Project[] = [
  {
    id: '1',
    title: 'Modern Office Tower',
    description: 'A 25-story sustainable commercial tower featuring energy-efficient design and premium materials throughout.',
    type: 'Commercial',
    image: 'https://images.pexels.com/photos/236705/pexels-photo-236705.jpeg',
    location: 'Downtown Metro',
    materials: ['Steel I-Beams', 'Concrete', 'Glass Curtain Wall', 'Solar Panels']
  },
  {
    id: '2',
    title: 'Luxury Residential Complex',
    description: 'Multi-family residential development with high-end finishes and amenities, built using quality construction materials.',
    type: 'Residential',
    image: 'https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg',
    location: 'Riverside Heights',
    materials: ['Premium Lumber', 'Natural Stone', 'Ceramic Tiles', 'Custom Fixtures']
  },
  {
    id: '3',
    title: 'Sustainable Community Center',
    description: 'LEED-certified community hub featuring sustainable building practices and locally sourced materials.',
    type: 'Public',
    image: 'https://images.pexels.com/photos/1134166/pexels-photo-1134166.jpeg',
    location: 'Greenfield District',
    materials: ['Recycled Steel', 'Bamboo Flooring', 'Low-VOC Paints', 'Smart Glass']
  },
  {
    id: '4',
    title: 'Industrial Warehouse Complex',
    description: 'Large-scale warehouse facility built for optimal efficiency and durability in industrial environments.',
    type: 'Industrial',
    image: 'https://images.pexels.com/photos/236705/pexels-photo-236705.jpeg',
    location: 'Harbor Commerce Park',
    materials: ['Steel Framework', 'Insulated Panels', 'Concrete Flooring', 'LED Lighting']
  },
  {
    id: '5',
    title: 'Historic Building Restoration',
    description: 'Careful restoration of a 19th-century landmark using traditional techniques and materials matching the original construction.',
    type: 'Restoration',
    image: 'https://images.pexels.com/photos/5244261/pexels-photo-5244261.jpeg',
    location: 'Old Town District',
    materials: ['Reclaimed Brick', 'Hardwood', 'Lime Mortar', 'Copper Roofing']
  },
  {
    id: '6',
    title: 'Modern Family Home',
    description: 'Custom-built single-family residence featuring contemporary design and energy-efficient construction.',
    type: 'Residential',
    image: 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg',
    location: 'Sunset Highlands',
    materials: ['Engineered Wood', 'Stone Veneer', 'Metal Roofing', 'Double-Pane Windows']
  }
];