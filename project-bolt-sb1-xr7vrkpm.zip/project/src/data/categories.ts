interface Category {
  id: string;
  name: string;
  slug: string;
  image: string;
  productCount: number;
  description?: string;
}

export const categories: Category[] = [
  {
    id: '1',
    name: 'Building Materials',
    slug: 'building-materials',
    image: 'https://images.pexels.com/photos/6461515/pexels-photo-6461515.jpeg',
    productCount: 158,
    description: 'Essential materials for construction including cement, bricks, lumber, and aggregates.'
  },
  {
    id: '2',
    name: 'Tools & Equipment',
    slug: 'tools-equipment',
    image: 'https://images.pexels.com/photos/4491881/pexels-photo-4491881.jpeg',
    productCount: 214,
    description: 'Professional tools and equipment for construction, from power tools to hand tools.'
  },
  {
    id: '3',
    name: 'Plumbing & Electrical',
    slug: 'plumbing-electrical',
    image: 'https://images.pexels.com/photos/1249610/pexels-photo-1249610.jpeg',
    productCount: 143,
    description: 'Complete range of plumbing pipes, fittings, electrical wiring, and fixtures.'
  },
  {
    id: '4',
    name: 'Paints & Finishes',
    slug: 'paints-finishes',
    image: 'https://images.pexels.com/photos/5691712/pexels-photo-5691712.jpeg',
    productCount: 87,
    description: 'Interior and exterior paints, stains, sealers, and specialty coatings.'
  },
  {
    id: '5',
    name: 'Safety Equipment',
    slug: 'safety-equipment',
    image: 'https://images.pexels.com/photos/585419/pexels-photo-585419.jpeg',
    productCount: 76,
    description: 'Personal protective equipment and jobsite safety solutions.'
  },
  {
    id: '6',
    name: 'Flooring & Tiles',
    slug: 'flooring-tiles',
    image: 'https://images.pexels.com/photos/276528/pexels-photo-276528.jpeg',
    productCount: 124,
    description: 'Wide selection of flooring options including tile, wood, laminate, and vinyl.'
  }
];