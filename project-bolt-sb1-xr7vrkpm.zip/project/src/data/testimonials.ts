interface Testimonial {
  id: string;
  name: string;
  title: string;
  avatar: string;
  quote: string;
  rating: number;
  project: string;
}

export const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Michael Rodriguez',
    title: 'General Contractor',
    avatar: 'https://randomuser.me/api/portraits/men/32.jpg',
    quote: 'BuildMaster has been our go-to supplier for the past five years. Their quality materials and reliable delivery have made our projects run smoother. I particularly appreciate their technical support team who always helps with material specifications.',
    rating: 5,
    project: 'Commercial Office Building, Downtown'
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    title: 'DIY Homeowner',
    avatar: 'https://randomuser.me/api/portraits/women/44.jpg',
    quote: 'As a first-time home renovator, I was overwhelmed by all the choices. The staff at BuildMaster patiently guided me through selecting the right materials for my bathroom remodel. Everything arrived on time and the quality exceeded my expectations!',
    rating: 5,
    project: 'Home Bathroom Renovation'
  },
  {
    id: '3',
    name: 'David Chen',
    title: 'Project Manager',
    avatar: 'https://randomuser.me/api/portraits/men/67.jpg',
    quote: 'We had a tight deadline for our multi-unit housing project, and BuildMaster delivered everything we needed ahead of schedule. Their bulk pricing saved us significantly on our budget without compromising on quality.',
    rating: 4,
    project: 'Multi-Family Housing Development'
  },
  {
    id: '4',
    name: 'Emily Wilson',
    title: 'Interior Designer',
    avatar: 'https://randomuser.me/api/portraits/women/75.jpg',
    quote: 'The selection of premium finishing materials at BuildMaster is impressive. My clients are always satisfied with the quality and aesthetic of the products we source from them. Their design consultants are knowledgeable and helpful.',
    rating: 5,
    project: 'Luxury Home Interior Design'
  }
];