import React from 'react';
import Hero from '../components/home/Hero';
import CategoryGrid from '../components/home/CategoryGrid';
import FeaturedProducts from '../components/home/FeaturedProducts';
import Testimonials from '../components/home/Testimonials';
import ProjectShowcase from '../components/home/ProjectShowcase';
import NewsletterForm from '../components/home/NewsletterForm';

const Home: React.FC = () => {
  return (
    <div>
      <Hero />
      <CategoryGrid />
      <FeaturedProducts />
      <div className="bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center gap-8">
            <div className="lg:w-1/2">
              <span className="inline-block text-primary text-sm font-semibold tracking-wider uppercase mb-2">Why Choose Us</span>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Your Trusted Partner in Construction</h2>
              <p className="text-gray-600 mb-8">
                With over 25 years of experience supplying quality construction materials, 
                BuildMaster has established itself as the industry leader. We offer:
              </p>
              
              <div className="space-y-4">
                {[
                  {
                    title: 'Premium Quality Materials',
                    description: 'All products meet or exceed industry standards and come with manufacturer warranties.'
                  },
                  {
                    title: 'Expert Advice',
                    description: 'Our team of construction professionals can help select the right materials for your project.'
                  },
                  {
                    title: 'Timely Delivery',
                    description: 'Reliable scheduling and delivery to keep your project on track.'
                  },
                  {
                    title: 'Competitive Pricing',
                    description: 'Best value without compromising on quality, with special rates for bulk orders.'
                  }
                ].map((item, index) => (
                  <div key={index} className="flex">
                    <div className="flex-shrink-0 h-6 w-6 rounded-full bg-primary flex items-center justify-center">
                      <svg 
                        className="h-4 w-4 text-white" 
                        xmlns="http://www.w3.org/2000/svg" 
                        viewBox="0 0 20 20" 
                        fill="currentColor"
                      >
                        <path 
                          fillRule="evenodd" 
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" 
                          clipRule="evenodd" 
                        />
                      </svg>
                    </div>
                    <div className="ml-4">
                      <h4 className="text-lg font-medium text-gray-900">{item.title}</h4>
                      <p className="mt-1 text-gray-600">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="lg:w-1/2">
              <div className="grid grid-cols-2 gap-4">
                <div className="aspect-square rounded-lg overflow-hidden">
                  <img 
                    src="https://images.pexels.com/photos/1216589/pexels-photo-1216589.jpeg" 
                    alt="Construction materials" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="aspect-square rounded-lg overflow-hidden mt-8">
                  <img 
                    src="https://images.pexels.com/photos/1374559/pexels-photo-1374559.jpeg" 
                    alt="Construction worker" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="aspect-square rounded-lg overflow-hidden">
                  <img 
                    src="https://images.pexels.com/photos/2219024/pexels-photo-2219024.jpeg" 
                    alt="Construction equipment" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="aspect-square rounded-lg overflow-hidden mt-8">
                  <img 
                    src="https://images.pexels.com/photos/3990359/pexels-photo-3990359.jpeg" 
                    alt="Construction site" 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <ProjectShowcase />
      <Testimonials />
      <NewsletterForm />
    </div>
  );
};

export default Home;